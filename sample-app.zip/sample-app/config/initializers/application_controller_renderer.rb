# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = '2bc12322ec1707e394395f4b86a8b855eab9fdcb2de34f069ab43a5ea82f9f7040ca33991c820aa3f3c5c09cc6cd0e5dadf4bd4eb199c1a3dbdaba8d7d3b2443'
